---
nombre: "Sofía Martínez"
rol: "Subdirectora"
avatar: ""
bio: "Gestión de soporte y revisión de reportes."
---
