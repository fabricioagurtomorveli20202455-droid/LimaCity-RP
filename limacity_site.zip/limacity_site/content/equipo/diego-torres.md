---
nombre: "Diego Torres"
rol: "Jefe de Moderación"
avatar: ""
bio: "Encargado de fair-play y sanciones."
---
