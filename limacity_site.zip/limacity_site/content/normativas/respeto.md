---
title: "Respeto"
---
Todos los jugadores deben tratar a los demás con respeto dentro y fuera del roleplay.
