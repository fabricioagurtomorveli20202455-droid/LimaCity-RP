---
producto: "Paquete de Monedas"
precio: 6.99
descripcion: "Monedas para comprar ítems estéticos."
url: ""
activo: true
---
