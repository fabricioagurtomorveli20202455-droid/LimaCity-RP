---
producto: "Paquete VIP"
precio: 9.99
descripcion: "Acceso prioritario y cosméticos exclusivos."
url: ""
activo: true
---
