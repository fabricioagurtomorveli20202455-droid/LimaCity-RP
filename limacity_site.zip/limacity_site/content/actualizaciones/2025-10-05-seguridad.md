---
title: "Mejoras de seguridad"
date: 2025-10-05 09:30:00
---
Se reforzaron detecciones anti-cheat y reportes.
